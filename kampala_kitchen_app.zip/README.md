# Kampala Kitchen — Expo Starter App

This is a multi-file starter project for the Kampala Kitchen mobile app (Expo / React Native).
It implements the UI and flows you requested: Splash, Entry (login/signup), Login, SignUp (with location),
Home (tabs: Quick / Next Day / Seclude), Product categories, Cart (with fixed 2,000 UGX delivery fee), Orders, Profile,
and a Cart context to manage the cart.

## How to run (quick)
1. Install Node.js and Expo CLI (`npm install -g expo-cli`).
2. Extract this folder and run `npm install`.
3. Start the app with `npm start` or `expo start`.
4. Open in Expo Go or an emulator.

## Notes
- This is a UI-first starter; replace the sample data with a real backend (auth, product catalogue, orders).
- Integrate Mobile Money / payment gateway on the server side for secure payments.
- Admin dashboard and deliverer portal are separate projects (I can scaffold them next).
