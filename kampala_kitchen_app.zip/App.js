import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CartProvider } from './context/CartContext';

import SplashScreen from './screens/Splash';
import EntryScreen from './screens/Entry';
import LoginScreen from './screens/Login';
import SignUpScreen from './screens/SignUp';
import MainTabs from './navigation/MainTabs';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <CartProvider>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{headerShown:false}}>
          <Stack.Screen name='Splash' component={SplashScreen} />
          <Stack.Screen name='Entry' component={EntryScreen} />
          <Stack.Screen name='Login' component={LoginScreen} />
          <Stack.Screen name='SignUp' component={SignUpScreen} />
          <Stack.Screen name='MainTabs' component={MainTabs} />
        </Stack.Navigator>
      </NavigationContainer>
    </CartProvider>
  );
}
