import React from 'react';
import { SafeAreaView, Text, View, FlatList, TouchableOpacity, Alert } from 'react-native';
import CartContext from '../context/CartContext';

export default function Cart(){
  const { items, subtotal, total, updateQty, removeItem, DELIVERY_FEE } = React.useContext(CartContext);
  return (
    <SafeAreaView style={{flex:1, backgroundColor:'#FFFDF8'}}>
      <Text style={{fontSize:20, fontWeight:'700', padding:16}}>My Cart</Text>
      <FlatList
        data={items}
        keyExtractor={(i)=>i.product.id + '_' + i.unit}
        ListEmptyComponent={<Text style={{textAlign:'center', marginTop:20}}>Cart is empty</Text>}
        renderItem={({item}) => (
          <View style={{flexDirection:'row', padding:12, alignItems:'center', borderBottomWidth:1, borderColor:'#F1F1F1'}}>
            <View style={{flex:1}}>
              <Text style={{fontWeight:'700'}}>{item.product.name}</Text>
              <Text style={{color:'#666'}}>{item.qty} x {item.product.price} UGX</Text>
            </View>
            <View style={{flexDirection:'row', alignItems:'center'}}>
              <TouchableOpacity style={{padding:8, borderRadius:6, backgroundColor:'#fff', borderWidth:1, borderColor:'#eee'}} onPress={()=> updateQty(item.product.id, item.unit, Math.max(0, item.qty-1)) }><Text>-</Text></TouchableOpacity>
              <Text style={{marginHorizontal:8}}>{item.qty}</Text>
              <TouchableOpacity style={{padding:8, borderRadius:6, backgroundColor:'#fff', borderWidth:1, borderColor:'#eee'}} onPress={()=> updateQty(item.product.id, item.unit, item.qty+1) }><Text>+</Text></TouchableOpacity>
            </View>
          </View>
        )}
      />

      <View style={{padding:16, borderTopWidth:1, borderColor:'#eee'}}>
        <View style={{flexDirection:'row', justifyContent:'space-between'}}>
          <Text>Subtotal</Text>
          <Text>{subtotal} UGX</Text>
        </View>
        <View style={{flexDirection:'row', justifyContent:'space-between', marginTop:8}}>
          <Text>Delivery</Text>
          <Text>{DELIVERY_FEE} UGX</Text>
        </View>
        <View style={{flexDirection:'row', justifyContent:'space-between', marginTop:8}}>
          <Text style={{fontWeight:'700'}}>Total</Text>
          <Text style={{fontWeight:'700'}}>{total} UGX</Text>
        </View>

        <TouchableOpacity style={{backgroundColor:'#D4AF37', padding:14, marginTop:12, borderRadius:12}} onPress={()=> Alert.alert('Checkout','Proceed to payment flow (placeholder)')}>
          <Text style={{fontWeight:'700'}}>Confirm & Pay</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
