import React from 'react';
import { View, TextInput, ScrollView, TouchableOpacity, Text, FlatList } from 'react-native';
import { CATEGORIES, SAMPLE_PRODUCTS } from '../sampleData';
import CartContext from '../context/CartContext';

export default function ProductCategories(){
  const [query, setQuery] = React.useState('');
  const [category, setCategory] = React.useState('fruits');
  const catProducts = SAMPLE_PRODUCTS[category] || [];
  const { addItem } = React.useContext(CartContext);

  return (
    <View style={{flex:1, padding:12}}>
      <TextInput placeholder='Search for an item' style={{backgroundColor:'#fff', padding:12, borderRadius:10}} value={query} onChangeText={setQuery} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginVertical:10}}>
        {CATEGORIES.map(c => (
          <TouchableOpacity key={c.id} onPress={()=>setCategory(c.id)} style={{padding:10, backgroundColor: category===c.id ? '#F2E8CE' : '#fff', borderRadius:20, marginRight:8}}>
            <Text>{c.title}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={catProducts.filter(p => p.name.toLowerCase().includes(query.toLowerCase()))}
        keyExtractor={i=>i.id}
        renderItem={({item}) => (
          <View style={{flexDirection:'row', padding:12, backgroundColor:'#fff', borderRadius:10, marginBottom:10, alignItems:'center'}}>
            <View style={{flex:1}}>
              <Text style={{fontWeight:'700'}}>{item.name}</Text>
              <Text style={{color:'#666'}}>{item.price} UGX / {item.unit}</Text>
            </View>
            <TouchableOpacity style={{padding:8, borderRadius:8, backgroundColor:'#F3E1C8'}} onPress={()=>addItem(item,1)}><Text>Add</Text></TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}
