import React from 'react';
import { SafeAreaView, View, Text, TouchableOpacity } from 'react-native';
import ProductCategories from './ProductCategories';

export default function Home(){
  const [activeTab, setActiveTab] = React.useState('quick');
  return (
    <SafeAreaView style={{flex:1, backgroundColor:'#FFFDF8'}}>
      <View style={{padding:16}}>
        <Text style={{fontSize:20, fontWeight:'700'}}>Kampala Kitchen</Text>
        <Text style={{color:'#666', marginTop:4}}>Fresh from the market to your table</Text>
      </View>

      <View style={{padding:16}}>
        <View style={{flexDirection:'row', justifyContent:'space-between'}}>
          <TouchableOpacity style={{flex:1, padding:12, marginHorizontal:6, borderRadius:10, backgroundColor:'#fff', alignItems:'center'}} onPress={()=>setActiveTab('quick')}>
            <Text style={{fontWeight:'700'}}>Quick Deliveries</Text>
            <Text style={{color:'#666'}}>Delivered within minutes</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{flex:1, padding:12, marginHorizontal:6, borderRadius:10, backgroundColor:'#fff', alignItems:'center'}} onPress={()=>setActiveTab('next')}>
            <Text style={{fontWeight:'700'}}>Next Day</Text>
            <Text style={{color:'#666'}}>Delivered the next day</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{flex:1, padding:12, marginHorizontal:6, borderRadius:10, backgroundColor:'#fff', alignItems:'center'}} onPress={()=>setActiveTab('seclude')}>
            <Text style={{fontWeight:'700'}}>Seclude Orders</Text>
            <Text style={{color:'#666'}}>Choose date & time</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ProductCategories />
    </SafeAreaView>
  );
}
