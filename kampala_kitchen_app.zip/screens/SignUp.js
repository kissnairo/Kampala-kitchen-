import React from 'react';
import { SafeAreaView, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default function SignUp({navigation}){
  const [identifier, setIdentifier] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [location, setLocation] = React.useState('');
  return (
    <SafeAreaView style={{flex:1, backgroundColor:'#FFFDF8'}}>
      <Text style={{fontSize:18, fontWeight:'800', padding:16}}>Create account</Text>
      <View style={{padding:20}}>
        <TextInput placeholder='Phone or email' style={{backgroundColor:'#fff', padding:12, borderRadius:10, marginTop:8}} value={identifier} onChangeText={setIdentifier} />
        <TextInput placeholder='Password' secureTextEntry style={{backgroundColor:'#fff', padding:12, borderRadius:10, marginTop:8}} value={password} onChangeText={setPassword} />
        <TextInput placeholder='Delivery location (address or landmark)' style={{backgroundColor:'#fff', padding:12, borderRadius:10, marginTop:8}} value={location} onChangeText={setLocation} />
        <TouchableOpacity style={{backgroundColor:'#D4AF37', padding:14, marginTop:16, borderRadius:12}} onPress={()=>navigation.replace('MainTabs')}>
          <Text style={{fontWeight:'700', textAlign:'center'}}>Create account</Text>
        </TouchableOpacity>
        <Text style={{marginTop:8, color:'#666'}}>You can edit this location later in Profile.</Text>
      </View>
    </SafeAreaView>
  );
}
