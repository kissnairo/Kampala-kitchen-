import React from 'react';
import { SafeAreaView, Text, View, TextInput } from 'react-native';

export default function Profile(){
  const [location, setLocation] = React.useState('Bunga, Kampala (sample)');
  return (
    <SafeAreaView style={{flex:1, backgroundColor:'#FFFDF8'}}>
      <Text style={{fontSize:20, fontWeight:'700', padding:16}}>Profile</Text>
      <View style={{padding:16}}>
        <Text style={{fontWeight:'700'}}>Delivery location</Text>
        <TextInput style={{backgroundColor:'#fff', padding:12, borderRadius:10, marginTop:8}} value={location} onChangeText={setLocation} />
        <Text style={{marginTop:12}}>Payment methods: Mobile Money preferred. (Configure in admin)</Text>
      </View>
    </SafeAreaView>
  );
}
