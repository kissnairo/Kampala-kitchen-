import React from 'react';
import { SafeAreaView, Text, View, TouchableOpacity, Image } from 'react-native';

export default function Entry({navigation}){
  return (
    <SafeAreaView style={{flex:1, backgroundColor:'#FFFDF8'}}>
      <Text style={{fontSize:20, fontWeight:'800', padding:16}}>Kampala Kitchen</Text>
      <View style={{flex:1, justifyContent:'center', alignItems:'center'}}>
        <Image source={{uri:'https://via.placeholder.com/200'}} style={{width:200,height:160, marginBottom:10}} />
        <TouchableOpacity style={{backgroundColor:'#D4AF37', padding:14, width:240, alignItems:'center', borderRadius:10}} onPress={()=>navigation.navigate('Login')}>
          <Text style={{fontWeight:'700'}}>Log in</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{padding:14, width:240, alignItems:'center', borderRadius:10, marginTop:12}} onPress={()=>navigation.navigate('SignUp')}>
          <Text style={{fontWeight:'700'}}>Sign up</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
