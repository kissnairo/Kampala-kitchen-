import React from 'react';
import { SafeAreaView, Text, View, TouchableOpacity } from 'react-native';

export default function Splash({navigation}){
  return (
    <SafeAreaView style={{flex:1, backgroundColor:'#FFFDF8', alignItems:'center', justifyContent:'center'}}>
      <Text style={{fontSize:32, fontWeight:'800'}}>Kampala Kitchen</Text>
      <Text style={{color:'#6B7280', marginTop:6}}>Fresh from the market to your table</Text>
      <View style={{width:260, height:180, borderRadius:18, backgroundColor:'#FFF7EB', marginTop:20, alignItems:'center', justifyContent:'center'}}>
        <Text style={{fontSize:34}}>🍎🥩🥚</Text>
      </View>
      <TouchableOpacity style={{backgroundColor:'#D4AF37', padding:14, marginTop:24, borderRadius:12}} onPress={()=>navigation.replace('Entry')}>
        <Text style={{fontWeight:'700'}}>Get started</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
