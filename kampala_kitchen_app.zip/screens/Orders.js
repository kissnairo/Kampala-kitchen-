import React from 'react';
import { SafeAreaView, Text, View } from 'react-native';

export default function Orders(){
  return (
    <SafeAreaView style={{flex:1, backgroundColor:'#FFFDF8'}}>
      <Text style={{fontSize:20, fontWeight:'700', padding:16}}>Orders</Text>
      <View style={{padding:16}}>
        <Text>No orders yet (placeholder)</Text>
      </View>
    </SafeAreaView>
  );
}
