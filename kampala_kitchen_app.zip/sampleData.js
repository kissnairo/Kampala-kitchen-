export const CATEGORIES = [
  { id: 'fruits', title: 'Fruits' },
  { id: 'eggs', title: 'Eggs' },
  { id: 'meat', title: 'Fresh Meat' },
  { id: 'staples', title: 'Staples' },
  { id: 'milk', title: 'Milk & Juice' },
  { id: 'spices', title: 'Spices & Veg' },
  { id: 'sugar', title: 'Sugar & Dry Goods' },
];

export const SAMPLE_PRODUCTS = {
  fruits: [
    { id: 'avocado1', name: 'Avocado (each)', unit: 'piece', price: 1500 },
    { id: 'mango1', name: 'Mango (each)', unit: 'piece', price: 800 },
    { id: 'banana1', name: 'Ripe Bananas (cluster)', unit: 'cluster', price: 2500 },
    { id: 'grapes1', name: 'Grapes (kg)', unit: 'kg', price: 4000 },
    { id: 'blueberry1', name: 'Blueberries (pack)', unit: 'pack', price: 8000 },
  ],
  eggs: [ { id: 'egg1', name: 'Egg (each)', unit: 'piece', price: 300 } ],
  meat: [
    { id: 'goat1', name: "Goat meat", unit: 'kg', price: 15000 },
    { id: 'beef1', name: 'Beef', unit: 'kg', price: 14000 },
    { id: 'pork1', name: 'Pork', unit: 'kg', price: 13000 },
    { id: 'chicken1', name: 'Chicken (kg)', unit: 'kg', price: 7000 },
  ],
  staples: [ { id: 'rice1', name: 'Rice (kg)', unit: 'kg', price: 3500 } ],
  milk: [ { id: 'milk1', name: 'Milk (liter)', unit: 'liter', price: 1200 } ],
  spices: [ { id: 'ginger', name: 'Ginger (500g)', unit: 'unit', price: 1000 }, { id: 'pepper', name: 'Green pepper (bunch)', unit: 'unit', price: 500 } ],
  sugar: [ { id: 'sugar1', name: 'Sugar (kg)', unit: 'kg', price: 3000 } ],
};
