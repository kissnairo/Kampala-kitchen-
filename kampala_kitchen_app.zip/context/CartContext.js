import React from 'react';

const CartContext = React.createContext();

const DELIVERY_FEE = 2000;

export function CartProvider({children}){
  const [items, setItems] = React.useState([]);

  function addItem(product, qty=1, unit=product.unit){
    setItems(prev=>{
      const found = prev.find(i => i.product.id === product.id && i.unit === unit);
      if(found) return prev.map(i => (i.product.id===product.id && i.unit===unit) ? {...i, qty: i.qty+qty} : i);
      return [...prev, {product, qty, unit}];
    });
  }

  function updateQty(productId, unit, qty){
    setItems(prev => prev.map(i => (i.product.id===productId && i.unit===unit) ? {...i, qty} : i));
  }

  function removeItem(productId, unit){
    setItems(prev => prev.filter(i => !(i.product.id===productId && i.unit===unit)));
  }

  function clear(){ setItems([]); }

  const subtotal = items.reduce((s,i)=>s + i.qty * i.product.price, 0);
  const total = subtotal + DELIVERY_FEE;

  return (
    <CartContext.Provider value={{items, addItem, updateQty, removeItem, clear, subtotal, total, DELIVERY_FEE}}>
      {children}
    </CartContext.Provider>
  );
}

export default CartContext;
