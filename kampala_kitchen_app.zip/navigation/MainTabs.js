import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from '../screens/Home';
import CartScreen from '../screens/Cart';
import OrdersScreen from '../screens/Orders';
import ProfileScreen from '../screens/Profile';

const Tab = createBottomTabNavigator();

export default function MainTabs(){
  return (
    <Tab.Navigator screenOptions={{headerShown:false}}>
      <Tab.Screen name='Home' component={HomeScreen} />
      <Tab.Screen name='Cart' component={CartScreen} />
      <Tab.Screen name='Orders' component={OrdersScreen} />
      <Tab.Screen name='Profile' component={ProfileScreen} />
    </Tab.Navigator>
  );
}
